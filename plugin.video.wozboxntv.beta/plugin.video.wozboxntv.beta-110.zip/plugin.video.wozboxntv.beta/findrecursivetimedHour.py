#print "findrecursivetimedHour.py"
import xbmcplugin,xbmcgui,xbmcaddon,xbmc
import urllib,urllib2,sys,re,os
import datetime
import time
import utils
import net
from hashlib import md5  
import json
import recordings, glob
import findrecursive
import locking

PLUGIN='plugin.video.wozboxntv.beta'
ADDON = xbmcaddon.Addon(id=PLUGIN)
if not locking.isAnyRecordLocked(): 
	streamtype = ADDON.getSetting('streamtype')
	if streamtype == '0':
		STREAMTYPE = 'NTV-XBMC-HLS-'
	elif streamtype == '1':
		STREAMTYPE = 'NTV-XBMC-'


	UA=STREAMTYPE + ADDON.getAddonInfo('version') 

	net=net.Net()
	datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
	cookie_path = os.path.join(datapath, 'cookies')
	loginurl = 'http://www.ntv.mx/index.php?' + recordings.referral()+ 'c=3&a=0'
	username    =ADDON.getSetting('user')
	password = md5(ADDON.getSetting('pass')).hexdigest()
	data     = {'email': username,
											'psw2': password,
											'rmbme': 'on'}
	headers  = {'Host':'www.ntv.mx',
											'Origin':'http://www.ntv.mx',
											'Referer':'http://www.ntv.mx/index.php?' + recordings.referral()+ 'c=3&a=0'}
											
	#create cookie
	html = net.http_POST(loginurl, data, headers)
	cookie_jar = os.path.join(cookie_path, "ntv.lwp")
	if os.path.exists(cookie_path) == False:
			os.makedirs(cookie_path)
	net.save_cookies(cookie_jar)
	#set cookie to grab url
	net.set_cookies(cookie_jar)
	imageUrl='http://www.ntv.mx/res/content/tv/'
	CatUrl='http://www.ntv.mx/res/content/categories/'    
	site='http://www.ntv.mx/index.php?' + recordings.referral()+ 'c=6&a=0'
	datapath = xbmc.translatePath(ADDON.getAddonInfo('profile'))
	cookie_path = os.path.join(datapath, 'cookies')
	cookie_jar = os.path.join(cookie_path, "ntv.lwp")
	findrecursive.RecursiveRecordingsPlanned('Hour')
	#xbmc.executebuiltin("Container.Refresh")

def deleteFile(file):
    tries    = 0
    maxTries = 10
    while os.path.exists(file) and tries < maxTries:
        try:
            os.remove(file)
            #print 'findrecursivetimed.py: Deleted os.remove(file)= %s' % repr(file)
            break
        except:
            xbmc.sleep(50)
            tries = tries + 1

lockDescription = '*Stop Recording*.flv'
recordingLock = os.path.join(ADDON.getSetting('record_path'),lockDescription)
LockFiles = glob.glob(recordingLock)
#print 'findrecursivetimed.py: recordingLock= %s' % (repr(LockFiles))
# delete lock files
for file in LockFiles:
	#print 'findrecursivetimed.py: delete file= %s' %repr(file)
	deleteFile(file)
